#!/bin/sh
BOARD_DIR="$(dirname $0)"

cp board/beagleboneai/uEnv.txt $BINARIES_DIR/uEnv.txt
